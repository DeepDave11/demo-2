
<div class="main-top">
        <div class="container-fluid">
           <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        <div id="offer-box" class="carouselTicker">
                            <ul class="offer-box">
                                <li>
                                    <i class="fab fa-opencart"></i> Apna Market-Bhavnagar.
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Apna Market-Bhavnagar.
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Apna Market-Bhavnagar.
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Apna Market-Bhavnagar.
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Apna Market-Bhavnagar.
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>



                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="right-phone-box">
        <p>

<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</p>               

 <p>Call US :- <a href="#">+91 6352 36 0909</a></p>
                    </div>
                    <div class="our-link">
                        <ul>
					
<?php if(isset($_SESSION['whole'])=="") { ?>
<li><a href="whole_regi.php">Create Account</a></li>
<li><a href="wholeseller_login.php">Login</a></li>							
<?php } else { ?>
<li><a href="add_products.php">Add Products</a></li>
<li><a href="view_my_products.php">View My Products</a></li>
<li><a href="wholeseller_profile.php">Profile</a></li>
<li><a href="wholeseller_changepwd.php">Change Password</a></li>
<li><a href="logout.php">Logout</a></li>
<?php } ?>
<li><a href="contact_us.php">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>