<?PHP
session_start();
?>
<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>			</a>		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Wholeseller View</span>
					</h2>
		  </div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							<div class="row">
								 
								 
								<table width="100%" border="1" align="center" class="table table-bordered">
  <tr>
    <td width="4%" class="bg-primary"><div align="center">No.</div></td>
    <td width="10%" class="bg-primary"><div align="center">Name</div></td>
    <td width="8%" class="bg-primary"><div align="center">Mobile No. </div></td>
    <td width="9%" class="bg-primary"><div align="center">Email</div></td>
    <td width="5%" class="bg-primary"><div align="center">Gender</div></td>
    <td width="8%" class="bg-primary"><div align="center">Shop Name </div></td>
    <td width="13%" class="bg-primary"><div align="center">Shop Address </div></td>
    <td width="10%" class="bg-primary"><div align="center">Shop Contect </div></td>
    <td width="10%" class="bg-primary"><div align="center">Shop Logo </div></td>
    <td width="12%" class="bg-primary"><div align="center">Login Id </div></td>
    <td colspan="2" class="bg-primary"><div align="center">Action</div></td>
  </tr>
  <?php
  include("connect.php");
  $no=1;
  $q=mysqli_query($dhy,"select * from whol_regi order by wid desc")or die("Qf");
  while($data=mysqli_fetch_array($q))
  {
 ?>
  <tr>
    <td><?php echo $no++;?></td>
    <td><?php echo $data['name'];?></td>
    <td><?php echo $data['mobile'];?></td>
    <td><?php echo $data['email'];?></td>
    <td><?php echo $data['gender'];?></td>
    <td><?php echo $data['shop_nm'];?></td>
    <td><?php echo $data['shop_addre'];?></td>
    <td><?php echo $data['shop_cnt'];?></td>
    <td><img src="../whole_seller/wholeseller_shplogo/<?php echo $data['shop_logo'];?>" width="100" height="100" /></td>
    <td><?php echo $data['lid'];?></td>
    <td width="6%"><a href="whol_del.php?d=<?php echo $data['wid'];?>"onclick="return f1();">Delete</a></td>
    <td width="5%">Edit</td>
  </tr>
<?php
$no++;
}
?>  
</table>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
		  </div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
<script>
function f1()
{
	var c=confirm("Are You Sure Delete Data???");
	if(c==false)
	return false;
}
</script>
