<?php
include("connect.php");
$d=$_REQUEST['d'];
$q=mysqli_query($dhy,"select shop_logo from whol_regi where wid=$d")or die("QF2");
$data=mysqli_fetch_array($q);
$fn=$data['shop_logo'];
$path="wholeseller_shplogo/";
$npath=$path.$fn;
unlink($npath);

$q=mysqli_query($dhy,"delete from whol_regi where wid=$d")or die("QF1");
header("location:wholeseller_view.php?m5=5");
?>