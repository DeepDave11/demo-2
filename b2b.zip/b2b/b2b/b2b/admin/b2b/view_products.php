<?PHP
session_start();
if(isset($_SESSION['admin'])=="")
{
	header("location:index.php?m1=1");
	exit(0);
}
?>
<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>			</a>		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>VIew Products</span>
					</h2>
		  </div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							<div class="row">
								 
								 
								 <table width="100%" border="1" class="table table-bordered">
  <tr>
    <td width="3%" class="bg-primary">No.</td>
    <td width="11%" class="bg-primary">Main Categories</td>
    <td width="10%" class="bg-primary">Sub Categories</td>
    <td width="11%" class="bg-primary">Company Brand </td>
    <td width="6%" class="bg-primary">Quantity</td>
    <td width="10%" class="bg-primary">Product Price </td>
    <td width="7%" class="bg-primary">Sell Price </td>
    <td width="5%" class="bg-primary">Photo1</td>
    <td width="5%" class="bg-primary">Wholeseller</td>
    <td colspan="2" align="center" class="bg-primary">Action</td>
  </tr>
  <?php 
  include("connect.php");
  extract($_POST);
  $no=1;
  $f=mysqli_query($dhy,"select * from products order by pid desc")or die("QF1");;
  while($data=mysqli_fetch_array($f))
  {
		$w=$data['wid'];
		$qw=mysqli_query($dhy,"select name from  whol_regi where wid=$w")or die ("QF1");
		$dataw=mysqli_fetch_array($qw);
  ?>
  
  <tr>
    <td><?php echo $no;?></td>
    <td><?php echo $data['m_name'];?></td>
    <td><?php echo $data['sub_cate_nm'];?></td>
    <td><?php echo $data['company_brand'];?></td>
    <td><?php echo $data['qty'];?></td>
    <td><?php echo $data['p_price'];?></td>
    <td><?php echo $data['s_price'];?></td>
    <td><img src="../product_photos/<?php echo $data['photo1'];?>"width="150" height="150"></td>
    <td><?php echo $dataw['name'];?></td>
    <td width="3%"><a href="product_del.php?d=<?php echo $data['pid'];?>"onclick="return f1();">Delete</a></td>
    <td width="1%"><a href="more_prod.php?p=<?php echo $data['pid'];?>">Readmore</a></td>
  </tr>
  <?php
  $no++;
  }
  ?>
</table>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
		  </div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
<script>
function f1()
{
	var c=confirm("Are You Sure Delete Data???");
	if(c==false)
	return false;
}
</script>
