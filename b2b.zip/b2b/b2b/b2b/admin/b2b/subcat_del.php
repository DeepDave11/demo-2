<?php
include("connect.php");
$d=$_REQUEST['d'];
$q=mysqli_query($dhy,"select * from sub_cat where cid=$d")or die("QF2");
$data=mysqli_fetch_array($q);


$q=mysqli_query($dhy,"delete from sub_cat where cid=$d")or die("QF1");
header("location:view_sub_cat.php?m5=5");
?>