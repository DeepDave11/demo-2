<?php 
	session_start();
if(isset($_SESSION['admin'])=="")
{
	header("location:index.php?m1=1");
	exit(0);
}
	$a=$_SESSION['admin'];
	include("connect.php");
	
	$q=mysqli_query($dhy," select * from admin where aid=$a")or die("QF");
	$data=mysqli_fetch_array($q);
	
	if(isset($_REQUEST['Submit']))
	{
		extract($_POST);
		mysqli_query($dhy," update admin set name='$nm',mobile='$mob',email='$em',login='$lid' where aid=$a")or die("QF1");
		header("location:admin_profile.php");
	}
?>
<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>			</a>		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Admin Edit Profile</span>
					</h2>
		  </div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							<div class="row">
								 
								 
								 <form id="form1" name="form1" method="post" action="">
  <table width="70%" border="1" align="center" class="table table-bordered">
    
    <tr>
      <td width="49%">Admin Name </td>
      <td width="2%">:</td>
      <td width="49%"><input name="nm" type="text" id="nm" value="<?php echo $data['name'];?>" /></td>
    </tr> 
    <tr>
      <td>Mobile Number </td>
      <td>:</td>
      <td><input name="mob" type="text" id="mob"  value="<?php echo $data['mobile'];?>"/></td>
    </tr>
    <tr>
      <td>Email Id </td>
      <td>:</td>
      <td><input name="em" type="text" id="em" size="35"  value="<?php echo $data['email'];?>"/></td>
    </tr>
    <tr>
      <td>Login id </td>
      <td>:</td>
      <td><input name="lid" type="text" id="lid"  value="<?php echo $data['login'];?>"/></td>
    </tr>
    <tr>
      <td colspan="3"><div align="center">
        <input type="submit" name="Submit" value="Update" onClick="return f1();" class="btn btn-primary"/>
      </div></td>
    </tr>
  </table>
</form>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
		  </div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
<script>
function f1()
{
if(from1.nm.value="")
{
	alert("Enter Your Name");
	from1.nm.focus();
	return false;
}
else if(frmo1.em.value="")
{
	alert("Enter Your Email Id");
	from1.em.focus();
	return false;
}
else if(frmo1.lid.value="")
{
	alert("Enter Your Login Id");
	from1.lid.focus();
	return false;
}
}
</script>
