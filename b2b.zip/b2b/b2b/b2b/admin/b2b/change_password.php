<?php 
session_start();
if(isset($_SESSION['admin'])=="")
{
	header("location:index.php?m1=1");
	exit(0);
}
include("connect.php");
$a=$_SESSION['admin'];
$q=mysqli_query($dhy,"select password from admin where aid=$a")or die("QF");
$data=mysqli_fetch_array($q);
$old_pwd=$data['password'];

if(isset($_REQUEST['Submit']))
{
	extract($_POST);
	
	if($old_pwd==$cp)
	{
		mysqli_query($dhy," update admin set password='$np' where aid=$a")or die("QF2");
		header("location:index.php");
	}
	else
	{
		//msg
		header("location:change_password.php");
	}
}
?>
<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>			</a>		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="index.html">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Change Password</span>
					</h2>
		  </div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							<div class="row">
								 
								 
								<form id="form1" name="form1" method="post" action="" onSubmit="return f1();">
  <table width="70%" border="1" align="center" class="table table-bordered">
    
    <tr>
      <td width="48%">Current Password </td>
      <td width="3%">:</td>
      <td width="49%"><input name="cp" type="password" id="cp" placeholder="Enter your Email or Mobile" autofocus /></td>
    </tr>
    <tr>
      <td>New Password</td>
      <td>:</td>
      <td><input name="np" type="password" id="np" placeholder="Enter your Password" /></td>
    </tr>
    <tr>
      <td>Retype Password </td>
      <td>:</td>
      <td><input name="rp" type="password" id="rp" placeholder="Retype your Password"  onblur="return f2();"  /></td>
    </tr>
    <tr>
      <td colspan="3"><div align="center">
        <input type="submit" name="Submit" value="Change" onclick ="return f2();"  class="btn btn-primary"/>
      </div></td>
    </tr>
  </table>
</form>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
		  </div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
<script>
function f1()
{
if(form1.np.value!=form1.rp.value)
	{
		alert("New And Re-Type Password not matched");
		form1.np.value='';
		form1.rp.value='';
		form1.np.focus();
		return false;
	}
}
</script>
<script>
function f2()
{
if(form1.cp.value=="")
	{
		alert("Enter Current Password");
		form1.cp.focus();
		return false;
	}
else if(form1.np.value=="")
	{
		alert("Enter New Password");
		form1.np.focus();
		return false;
	}
else if(form1.rp.value=="")
	{
		alert("Enter Re-Type New Password");
		form1.rp.focus();
		return false;
	}
}	
</script>

