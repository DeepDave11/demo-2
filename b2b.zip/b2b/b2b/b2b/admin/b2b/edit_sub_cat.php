<?PHP
include("connect.php");
session_start();
if(isset($_SESSION['admin'])=="")
{
	header("location:index.php?m1=1");
	exit(0);
}

$u=$_REQUEST['u'];
$qm=mysqli_query($dhy,"Select  * from  sub_cat where cid=$u")or die ("QF1");
$datam=mysqli_fetch_array($qm);



if(isset($_REQUEST['Submit']))
{
	
	extract($_POST);
	mysqli_query($dhy,"update  sub_cat set main_cate_nm='$mnm',sub_cate_nm='$snm' where cid=$u")or die("QF1");
	
	header("location:view_sub_cat.php?m6=7");
}
?>
<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>			</a>		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Sub categories</span>
					</h2>
</div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							 
								 
								 
								 <div class="row">
							  <form name="form1" id="form1" method="post" action="" onSubmit="return f1();">
							    <table width="50%" border="1" align="center" class="table table-bordered">
                                  <tr>
                                    <td> Main Category Name </td>
                                    <td>:</td>
                                    <td><select name="mnm" id="mnm" >
                                      
<?php
$qm1=mysqli_query($dhy,"select * from main_cat order by m_name")or die ("QF");
while($datam1=mysqli_fetch_array($qm1))
{ 
?>                                      
<option value="<?php echo $datam['main_cate_nm'];?>" <?php if($datam1['m_name']==$datam-['main_cate_nm']) { ?>selected="selected" <?php }?>><?php echo $datam1['m_name'];?></option>
<?php
}
?>
                                    </select>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td> Sub Category Name</td>
                                    <td>:</td>
                                    <td><input name="snm" type="text" id="snm" value="<?php echo $datam['sub_cate_nm'];?>"  onKeyUp="return f();" placeholder=" Sub Category Name" ></td>
                                  </tr>
                                  <tr>
                                    <td colspan="3">                                      <div align="center">
                                      <input type="submit" name="Submit" value="UPDATE" class="btn btn-primary">                                    
                                    </div></td>
                                  </tr>
                                </table>
                              </form>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					 
				</div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
<script language="javascript">
function f1()
{
	if(form1.mnm.value=="Select Main Cat.")
	{
		alert("Select Main Category Name");
		form1.mnm.focus();
		return false;
	}
else if(form1.snm.value=="")
	{
		alert("Enter Sub Category Name");
		form1.snm.focus();
		return false;
	}
}
</script>
<script>
function f()
{
	form1.snm.value=form1.snm.value.toUpperCase();
}
</script>
