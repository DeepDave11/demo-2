<?php
include("connect.php");
$d=$_REQUEST['d'];
$q=mysqli_query($dhy,"select * from products where pid=$d")or die("QF2");
$data=mysqli_fetch_array($q);

$fn=$data['photo1'];
$path="../product_photos/";
$npath=$path.$fn;
unlink($npath);

$fb=$data['photo2'];
 $npath1=$path.$fb;
unlink($npath1);

$fc=$data['photo3'];
 $npath2=$path.$fc;
unlink($npath2);


$q=mysqli_query($dhy,"delete from products where pid=$d")or die("QF1");
header("location:view_products.php?m5=5");
?>