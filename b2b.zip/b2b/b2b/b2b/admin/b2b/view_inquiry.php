<?PHP
session_start();
if(isset($_SESSION['admin'])=="")
{
	header("location:index.php?m1=1");
	exit(0);
}
?>
<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>
			</a>
		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>View Inquiry</span>
					</h2>
				</div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							<div class="row">
								 
								 
								<table width="100%" border="1" class="table table-bordered" align="center">
  <tr>
    <td class="bg-primary"><div align="center">No.</div></td>
    <td class="bg-primary"><div align="center">Name</div></td>
    <td class="bg-primary"><div align="center">Email</div></td>
    <td class="bg-primary"><div align="center">Mobile No. </div></td>
    <td class="bg-primary"><div align="center">Subject</div></td>
    <td class="bg-primary"><div align="center">Message</div></td>
    <td colspan="2" align="center" class="bg-primary">Action</td>
  </tr>
  <?php
  include("connect.php");
  extract($_POST);
  $no=1;
  $f=mysqli_query($dhy,"select * from inquiry order by iid desc")or die("Qf1");
  while($data=mysqli_fetch_array($f))
  {
  ?>
  <tr>
    <td><?php echo $no;?></td>
    <td><?php echo $data['name'];?></td>
    <td><?php echo $data['email'];?></td>
    <td><?php echo $data['mobile'];?></td>
    <td><?php echo $data['subject'];?></td>
    <td><?php echo $data['message'];?></td>
    <td><a href="inquiry_del.php?d=<?php echo $data['iid'];?>"onclick="return f1();">Delete</a></td>
    <td>Update</td>
  </tr>
  <?php
  $no++;
  }
  ?>
</table>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
				</div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
<script>
function f1()
{
	var c=confirm("Are You Sure Delete Data???");
	if(c==false)
	return false;
}
</script>