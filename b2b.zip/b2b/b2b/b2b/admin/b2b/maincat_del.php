<?php
include("connect.php");
$d=$_REQUEST['d'];
$q=mysqli_query($dhy,"select * from main_cat where mid=$d")or die("QF2");
$data=mysqli_fetch_array($q);


$q=mysqli_query($dhy,"delete from main_cat where mid=$d")or die("QF1");
header("location:view_main_cat.php?m5=5");
?>