<nav class="main-menu">
		<ul>
			<li>
				<a href="home.php">
					<i class="fa fa-home nav_icon"></i>
					<span class="nav-text">
					Dashboard
					</span>
				</a>
			</li>
			<li class="has-subnav">
				<a href="javascript:;">
				<i class="fa fa-cogs" aria-hidden="true"></i>
				<span class="nav-text">
					Main Cat.
				</span>
				<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
					<a class="subnav-text" href="add_main_cat.php">
					Add Main Cat.
					</a>
					</li>
					<li>
					<a class="subnav-text" href="view_main_cat.php">
					View Main Cat.
					</a>
					</li>
				</ul>
			</li>
			<li class="has-subnav">
				<a href="javascript:;">
				<i class="fa fa-cogs" aria-hidden="true"></i>
				<span class="nav-text">
					Sub Cat.
				</span>
				<i class="icon-angle-right"></i><i class="icon-angle-down"></i>
				</a>
				<ul>
					<li>
					<a class="subnav-text" href="add_sub_cat.php">
					Add Sub Cat.
					</a>
					</li>
					<li>
					<a class="subnav-text" href="view_sub_cat.php">
					View Sub Cat.
					</a>
					</li>
				</ul>
			</li>
			<li>
				<a href="wholeseller_view.php">
					<i class="fa fa-home nav_icon"></i>
					<span class="nav-text">
					Wholeseller
					</span>
				</a>
			</li>
			<li>
				<a href="view_Products.php">
					<i class="fa fa-home nav_icon"></i>
					<span class="nav-text">
					View Products
					</span>
				</a>
			</li>
			<li>
				<a href="view_inquiry.php">
					<i class="fa fa-home nav_icon"></i>
					<span class="nav-text">
					View Inquiry
					</span>
				</a>
			</li>
		</ul>
	</nav>