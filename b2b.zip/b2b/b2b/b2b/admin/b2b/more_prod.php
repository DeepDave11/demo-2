<?PHP
include("connect.php");
session_start();
if(isset($_SESSION['admin'])=="")
{
	header("location:index.php?m1=1");
	exit(0);
}
 $p=$_REQUEST['p'];
	//$w=
	include("connect.php");
	$qp=mysqli_query($dhy,"select * from products where pid=$p")or die ("QF");
$datap=mysqli_fetch_array($qp);

?>

<!DOCTYPE html>
<head>
<title>Title Here</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="KW HERE" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});	
		});
		</script>
<!-- charts -->
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
<link rel="stylesheet" href="css/morris.css">
<!-- //charts -->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>
<body class="dashboard-page">
	<script>
	        var theme = $.cookie('protonTheme') || 'default';
	        $('body').removeClass (function (index, css) {
	            return (css.match (/\btheme-\S+/g) || []).join(' ');
	        });
	        if (theme !== 'default') $('body').addClass(theme);
        </script>
	<?php include("menu.php");?>
	<section class="wrapper scrollable">
		<nav class="user-menu">
			<a href="javascript:;" class="main-menu-access">
			<i class="icon-proton-logo"></i>
			<i class="icon-reorder"></i>			</a>		</nav>
		<?php include("top.php");?>
		<div class="main-grid">
			
			 <div class="banner">
					<h2>
						<a href="home.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Product Details</span>
					</h2>
</div>
			<br><br>
			 <div class="panel variations-panel">
					<div class="panel-body mtn">
						<div class="col-adjust-8">

							
							 
								 
								 
								 <div class="row">
							   
							    <table width="50%" border="1" align="center" class="table table-bordered">
                                  <tr>
                                    <td width="34%"> Main Category Name </td>
                                    <td width="1%">:</td>
                                    <td width="65%"><?php echo $datap['m_name'];?></td>
                                  </tr>
                                  <tr>
                                    <td> Sub Category Name</td>
                                    <td>:</td>
                                    <td><?php echo $datap['sub_cate_nm'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Company Name - Brand </td>
                                    <td>:</td>
                                    <td><?php echo $datap['company_brand'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Quantity</td>
                                    <td>:</td>
                                    <td><?php echo $datap['qty'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Purchase Price </td>
                                    <td>:</td>
                                    <td><?php echo $datap['p_price'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Sell Price </td>
                                    <td>:</td>
                                    <td><?php echo $datap['s_price'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Size</td>
                                    <td>:</td>
                                    <td><?php echo $datap['size'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Color</td>
                                    <td>:</td>
                                    <td><?php echo $datap['color'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Photo1</td>
                                    <td>:</td>
                                    <td><img src="../product_photos/<?php echo $datap['photo1'];?>"width="150" height="150"></td>
                                  </tr>
                                  <tr>
                                    <td>Photo2</td>
                                    <td>:</td>
                                    <td><img src="../product_photos/<?php echo $datap['photo2'];?>"width="150" height="150"></td>
                                  </tr>
                                  <tr>
                                    <td>Photo3</td>
                                    <td>:</td>
                                    <td><img src="../product_photos/<?php echo $datap['photo3'];?>"width="150" height="150"></td>
                                  </tr>
                                  <tr>
                                    <td>Wholeseller</td>
                                    <td>:</td>
                                    <td><?php echo $datap['name'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Purchase Date </td>
                                    <td>:</td>
                                    <td><?php echo $datap['p_date'];?></td>
                                  </tr>
                                  <tr>
                                    <td>Discount</td>
                                    <td>:</td>
                                    <td><?php echo $datap['discount'];?></td>
                                  </tr>
                                </table>
                 
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					 
				</div>
			
			 
			 
			 
		</div>
		<!-- footer -->
		<?php include("footer.php");?>
		<!-- //footer -->
	</section>
	<script src="js/bootstrap.js"></script>
	<script src="js/proton.js"></script>
</body>
</html>
 
