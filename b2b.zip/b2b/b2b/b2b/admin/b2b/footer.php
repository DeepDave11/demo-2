<div class="footer">
			<p>All Rights Reserved for Apna-Market &copy;. Powered by <a href="#">Deep Dave</a></p>
		</div>