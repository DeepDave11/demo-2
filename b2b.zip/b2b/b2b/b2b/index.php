<?php
session_start();
include("connect.php");
$dt=date('Y-m-d');
$ip=$_SERVER['REMOTE_ADDR'];
$q1=mysqli_query($dhy,"select * from visitor where ip_add='$ip' and d_date='$dt'")or die ("QF3");
if(!mysqli_num_rows($q1))
{	
mysqli_query($dhy,"insert into visitor (ip_add,d_date)values('$ip','$dt')")or die("QF1");
}
?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Title Here</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="shortcut icon" href="icon.png" type="image/ico" />

<link rel="shortcut icon" href="icon.png" type="image/ico" />

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <?php include("top.php");?>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light brand-center bg-light navbar-default bootsnav">
            <?php include("menu.php");?>
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    <!-- End Top Search -->

    <!-- Start Slider -->
    <div id="slides-shop" class="cover-slides">
        <ul class="slides-container">
            <li class="text-left">
                <img src="images/banner-01.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 slider-main">
                            <h1 class="m-b-20"><strong>Welcome To <br> Apna market</strong></h1>
                            <p class="m-b-40">See how your users experience your website in realtime or view <br> trends to see any changes in performance over time.</p>
                            <p><a class="btn hvr-bounce-to-bottom" href="#">Shop New</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-center">
                <img src="images/banner-02.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 slider-main">
                            <h1 class="m-b-20"><strong>Welcome To <br> Apna market</strong></h1>
                            <p class="m-b-40">See how your users experience your website in realtime or view <br> trends to see any changes in performance over time.</p>
                            <p><a class="btn hvr-bounce-to-bottom" href="#">Shop New</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-right">
                <img src="images/banner-03.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 slider-main">
                            <h1 class="m-b-20"><strong>Welcome To <br> Apna market</strong></h1>
                            <p class="m-b-40">See how your users experience your website in realtime or view <br> trends to see any changes in performance over time.</p>
                            <p><a class="btn hvr-bounce-to-bottom" href="#">Shop New</a></p>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <div class="slides-navigation">
            <a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            <a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
        </div>
    </div>
    <!-- End Slider -->
	
	<!-- Start Sale  -->
	 
	<!-- End Sale -->

    <!-- Start Products  -->
    <div class="products-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-all text-center">
                        <h1>Our Products</h1>
                         
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="special-menu text-center">
                        <div class="button-group filter-button-group">
                            <button class="active" data-filter="*">All</button>
                            
<?php
$qpro=mysqli_query($dhy,"select * from products group by sub_cate_nm order by pid desc  limit 5")or die ("QF prod");
while($datapro=mysqli_fetch_array($qpro))
{
?>
<button data-filter=".<?php echo $datapro['sub_cate_nm'];?>"><?php echo $datapro['sub_cate_nm'];?></button>
<?php
}
?>
                             
                        </div>
                    </div>
                </div>
            </div>

            <div class="row special-list">
     <?php
$qq1=mysqli_query($dhy,"select * from products order by pid desc")or die ("QF");
while($data11=mysqli_fetch_array($qq1))
{
?>            
 <div class="col-lg-3 col-md-6 special-grid <?php echo $data11['sub_cate_nm'];?>">
                  
<div class="products-single fix">
                        <div class="box-img-hover">
                            <div class="type-lb">
                                <p class="sale">Sale</p>
                            </div>
                            <img src="product_photos/<?php echo $data11['photo1'];?>" class="img-fluid" alt="Image">
                            <div class="mask-icon">
                                <ul>
                                    <li><a href="#" title="View" data-toggle="modal" data-target="#product_view_<?php echo $data11['pid'];?>"><i class="fas fa-eye"></i></a></li>
                                    <li><a href="#" data-toggle="tooltip" data-placement="right" title="Compare"><i class="fas fa-sync-alt"></i></a></li>
                                    <li><a href="#" data-toggle="tooltip" data-placement="right" title="Add to Wishlist"><i class="far fa-heart"></i></a></li>
                                </ul>
                                <a class="cart hvr-bounce-to-bottom" href="#">Add to Cart</a>
                            </div>
                        </div>
                        <div class="why-text">
                            <h4><?php echo $data11['sub_cate_nm'];?></h4>
                            <h5>&#8377;<?php echo $data11['s_price'];?></h5>
                        </div>
                    </div>
             </div>

    <?php } ?> 
			</div>
        </div>
    </div>
    <!-- End Products  -->

    <!-- Start Blog  -->
     
    <!-- End Blog  -->

	<!-- Start info shop  -->
	<div class="info-box">
		<div class="container">
			<div class="row no-gutters">
				<div class="col-sm-6 col-lg-3">
					<div class="media service-block">
						<div class="service-block-icon"> <i class="fas fa-truck"></i> </div>
						<div class="media-body">
							<h6>FREE SHIPPING &amp; RETURN</h6>
							<div class="service-block-desc">Get free shipping for all orders $99 or more</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-lg-3">
					<div class="media service-block">
						<div class="service-block-icon"> <i class="fas fa-sync-alt"></i> </div>
						<div class="media-body">
							<h6>MONEY BACK GUARANTEE</h6>
							<div class="service-block-desc">Get the item you ordered, or your money back</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-lg-3">
					<div class="media service-block">
						<div class="service-block-icon"> <i class="fas fa-shield-alt"></i> </div>
						<div class="media-body">
							<h6>100% SECURE PAYMENT</h6>
							<div class="service-block-desc">Your transaction are secure with SSL Encryption</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-lg-3">
					<div class="media service-block">
						<div class="service-block-icon"> <i class="fas fa-phone"></i> </div>
						<div class="media-body">
							<h6>ONLINE SUPPORT 24/7</h6>
							<div class="service-block-desc">Chat with experts or have us call you right away</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End info shop  -->
	
			<!-- Start Footer  -->
    
    <!-- End Footer  -->

    <!-- Start copyright  -->
    <?php include("footer.php");?>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;"><i class="fas fa-angle-double-up"></i></a>
	
<?php
$qq2=mysqli_query($dhy,"select * from products order by pid desc")or die ("QF");
while($data22=mysqli_fetch_array($qq2))
{
?>   
<form name="frm1" id="frm1" method="post" action="invoice.php">
<input type="hidden" name="pr" value="<?php echo $data22['s_price'];?>">
<input type="hidden" name="dis" value="<?php echo $data22['discount'];?>">
<input type="hidden" name="pid" value="<?php echo $data22['pid'];?>">
<input type="hidden" name="wid_s" value="<?php echo $data22['wid'];?>">
<div class="modal fade product_view_<?php echo $data22['pid'];?>" id="product_view_<?php echo $data22['pid'];?>">
		<div class="modal-dialog modal-dialog-centered modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h3 class="modal-title"><?php echo $data22['m_name'];?>-<?php echo $data22['sub_cate_nm'];?></h3>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-md-6 product_img">
							<img src="product_photos/<?php echo $data22['photo1'];?>" class="img-fluid" height="150" width="100">
&nbsp;&nbsp;<img src="product_photos/<?php echo $data22['photo2'];?>" class="img-fluid" height="150" width="100">&nbsp;&nbsp;<img src="product_photos/<?php echo $data22['photo3'];?>" class="img-fluid" height="150" width="100">
						</div>
						<div class="col-md-6 product_content">
							<h4>Product Id: <span><?php echo $data22['pid'];?></span></h4>
							<div class="rating">
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								(10 reviews)
							</div>
							<p>Brand - <?php echo $data22['company_brand'];?></p>
							<p>Discount - <?php echo $data22['discount'];?>%</p>
							<h3 class="cost">&#8377;<?php echo $data22['s_price'];?> </h3>
							<div class="row mb-4">
								<div class="col-md-4 col-sm-6 col-xs-12">
									<select class="form-control" name="select">
										<option value="" selected="">Color</option>
										<option ><?php echo $data22['color'];?></option>
										
									</select>
								</div>
								<!-- end col -->
								<div class="col-md-4 col-sm-6 col-xs-12">
									<select class="form-control" name="select">
										<option value="">Size</option>
										<option value=""><?php echo $data22['size'];?></option>
										
									</select>
								</div>
								<!-- end col -->
								<div class="col-md-4 col-sm-12">
									<input name="qty" type="text"  id="qty" size="7" placeholder="Quantity" />
								</div>  
								<!-- end col -->
							</div>
							
							<div class="btn-ground">
								
<input type="submit" name="btn" class="mybtn btn hvr-bounce-to-bottom" value="Buy Now">


	
 		 					</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>
<?php
}
?>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>
<?php if(isset($_REQUEST['m5'])=="5"){?>
<script>
alert("Product Added Sucessfully");
</script>
<?php }?>
