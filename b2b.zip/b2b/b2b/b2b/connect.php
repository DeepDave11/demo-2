<?php 
$dhy=mysqli_connect("localhost","bhavnagarvruddha_de_hi_yv","Web#myweb@","bhavnagarvruddha_b2b_db")or die("CF");
?>